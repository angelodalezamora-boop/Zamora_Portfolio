# BSIT Industry-Ready Portfolio

Personal portfolio website with a **Node.js/Express backend** and a responsive HTML/CSS/JS frontend.
Sections: Home, Professional Profile, Technical Skills, Projects, Problem-Solving, Employability,
Resume, Certificates/Achievements, GitHub, Contact, Reflection.

## Features
- Content lives in `data/portfolio.json` (served by `GET /api/portfolio`) — edit text, not code
- `POST /api/contact` validates input, rate-limits, and stores messages in `data/messages.json`
- Live GitHub repositories pulled from the GitHub API
- Responsive, keyboard accessible, light/dark aware

## Run locally
```bash
npm install
npm start        # http://localhost:3000
```

## Customize
1. Edit `data/portfolio.json` (name, skills, projects, certificates, reflection, `githubUser`)
2. Put your resume at `public/resume.pdf`

## Deploy (backend needs a Node host)
- **Render / Railway:** New Web Service → connect this repo → Build `npm install`, Start `npm start`
- Static-only option (GitHub Pages): contact form will not work; the site falls back to reading `data/portfolio.json`
