const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const tags = (a) => `<ul class="tags">${a.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>`;
const link = (u, t) => (u ? `<a href="${esc(u)}" target="_blank" rel="noopener">${t}</a>` : "");
const SECTIONS = [["home", "Home"], ["profile", "Profile"], ["skills", "Skills"], ["projects", "Projects"],
  ["problem-solving", "Problem-solving"], ["employability", "Employability"], ["resume", "Resume"],
  ["certificates", "Certificates"], ["github", "GitHub"], ["contact", "Contact"], ["reflection", "Reflection"]];

async function init() {
  let d;
  try { d = await (await fetch("/api/portfolio")).json(); }
  catch { d = await (await fetch("data/portfolio.json")).json(); }
  document.title = `${d.name} | Portfolio`;
  $("brand").textContent = d.name;
  $("h-name").textContent = d.name;
  $("h-title").textContent = d.title;
  $("h-tag").textContent = d.tagline;
  $("foot").textContent = `© ${new Date().getFullYear()} ${d.name}`;
  $("nav").innerHTML = SECTIONS.map(([id, t]) => `<a href="#${id}">${t}</a>`).join("");
  const stack = d.skills.slice(0, 2).flatMap((g) => g.items.slice(0, 2)).map((s) => `<span class="s">"${esc(s)}"</span>`).join(", ");
  $("term").innerHTML = `<span class="c">// whoami</span>\n<span class="k">const</span> dev = {\n  name: <span class="s">"${esc(d.name)}"</span>,\n  degree: <span class="s">"BSIT"</span>,\n  stack: [${stack}],\n  openToWork: <span class="k">true</span>\n};\n`;
  $("profile-body").innerHTML = `<p>${esc(d.profile.about)}</p><p><b>Education:</b> ${esc(d.profile.education)}<br><b>Location:</b> ${esc(d.profile.location)}</p>`;
  $("skills-body").innerHTML = d.skills.map((g) => `<article class="card"><h3>${esc(g.group)}</h3>${tags(g.items)}</article>`).join("");
  $("projects-body").innerHTML = d.projects.map((p) => `<article class="card"><h3>${esc(p.title)}</h3><p>${esc(p.summary)}</p>${tags(p.stack)}<div class="links">${link(p.repo, "Source code")}${link(p.demo, "Live demo")}</div></article>`).join("");
  $("ps-body").innerHTML = d.problemSolving.map((c) => `<article class="card case">${[["Problem", c.problem], ["Approach", c.approach], ["Solution", c.solution], ["Result", c.result]].map(([h, t]) => `<div><h4>${h}</h4><p>${esc(t)}</p></div>`).join("")}</article>`).join("");
  const e = d.employability;
  $("emp-body").innerHTML = `<div class="prose"><p>${esc(e.internship)}</p>${tags(e.softSkills)}</div><div class="timeline">${e.careerPlan.map((c) => `<div><b>${esc(c.when)}</b>${esc(c.goal)}</div>`).join("")}</div>`;
  $("resume-body").innerHTML = `<p><a class="btn primary" href="${esc(d.resume.file)}" download>Download resume (PDF)</a></p>`;
  $("cert-body").innerHTML = d.certificates.map((c) => `<article class="card"><h3>${esc(c.title)}</h3><p>${esc(c.issuer)} · ${esc(c.year)}</p></article>`).join("");
  $("links").innerHTML = `${link("mailto:" + d.email, esc(d.email))} · ${link(d.linkedin, "LinkedIn")} · ${link("https://github.com/" + d.githubUser, "GitHub")}`;
  $("ref-body").innerHTML = `<p>${esc(d.reflection)}</p>`;
  loadGitHub(d.githubUser);
  spy();
}

async function loadGitHub(user) {
  const box = $("gh-body");
  try {
    const r = await fetch(`https://api.github.com/users/${encodeURIComponent(user)}/repos?sort=updated&per_page=6`);
    if (!r.ok) throw 0;
    const repos = (await r.json()).filter((x) => !x.fork);
    if (!repos.length) throw 0;
    box.innerHTML = repos.map((x) => `<article class="card"><h3>${esc(x.name)}</h3><p>${esc(x.description || "No description yet.")}</p>${tags([x.language || "Code", `★ ${x.stargazers_count}`])}<div class="links">${link(x.html_url, "Open repository")}</div></article>`).join("");
  } catch {
    box.innerHTML = `<p>Set <code>githubUser</code> in <code>data/portfolio.json</code> to show your latest repositories.</p>`;
  }
}

function spy() {
  const links = [...document.querySelectorAll("nav a")];
  const io = new IntersectionObserver((es) => es.forEach((x) => {
    if (x.isIntersecting) links.forEach((a) => a.classList.toggle("on", a.hash === "#" + x.target.id));
  }), { rootMargin: "-40% 0px -55% 0px" });
  document.querySelectorAll("main section").forEach((s) => io.observe(s));
}

document.querySelector(".menu").addEventListener("click", (ev) => {
  const open = $("nav").classList.toggle("open");
  ev.currentTarget.setAttribute("aria-expanded", open);
});
$("nav").addEventListener("click", () => $("nav").classList.remove("open"));

$("contact-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const s = $("form-status"), f = ev.target;
  s.className = ""; s.textContent = "Sending…";
  try {
    const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(f))) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error);
    f.reset(); s.className = "ok"; s.textContent = "Message sent. I'll reply by email.";
  } catch (err) { s.className = "err"; s.textContent = err.message || "Could not send. Email me directly instead."; }
});
init();
