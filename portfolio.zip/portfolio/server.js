const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data");
const MESSAGES = path.join(DATA, "messages.json");

app.use(express.json({ limit: "10kb" }));
app.use((req, res, next) => {
  res.set("X-Content-Type-Options", "nosniff");
  res.set("X-Frame-Options", "DENY");
  next();
});
app.use(express.static(path.join(__dirname, "public")));

// Portfolio content (edit data/portfolio.json, no code changes needed)
app.get("/api/portfolio", (req, res) => {
  res.json(JSON.parse(fs.readFileSync(path.join(DATA, "portfolio.json"), "utf8")));
});

// Contact form with validation + simple rate limit (5 per 10 min per IP)
const hits = new Map();
app.post("/api/contact", (req, res) => {
  const ip = req.ip, now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 600000);
  if (recent.length >= 5) return res.status(429).json({ error: "Too many messages. Try again later." });

  const { name, email, message } = req.body || {};
  const clean = (s, max) => String(s || "").trim().slice(0, max);
  const n = clean(name, 80), e = clean(email, 120), m = clean(message, 2000);
  if (!n || !m || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e))
    return res.status(400).json({ error: "Enter your name, a valid email, and a message." });

  const list = fs.existsSync(MESSAGES) ? JSON.parse(fs.readFileSync(MESSAGES, "utf8")) : [];
  list.push({ name: n, email: e, message: m, at: new Date().toISOString() });
  fs.writeFileSync(MESSAGES, JSON.stringify(list, null, 2));
  hits.set(ip, [...recent, now]);
  res.status(201).json({ ok: true });
});

app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));
